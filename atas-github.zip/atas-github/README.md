# Atas e Assinaturas · Umuarama Autos

Sistema de atas de reunião (Vendas, Pós-vendas, CEM e CSI) com assinatura digital por funcionário, painel do administrador e impressão em A4.

## Estrutura
- `index.html` – aplicação (HTML + JavaScript)
- `css/style.css` – design system (tema escuro corporativo)
- `.nojekyll` – desativa o Jekyll no GitHub Pages

## Publicar no GitHub Pages
1. Crie um repositório (ex.: `atas-umuarama`) e envie estes arquivos na raiz.
2. Em **Settings → Pages**, escolha **Deploy from a branch → main → / (root)**.
3. O site abre em `https://SEU-USUARIO.github.io/atas-umuarama/`.

## IMPORTANTE: armazenamento e login
O armazenamento das atas/assinaturas (`db`), o login e o upload de arquivos usam recursos do Claude
(`window.claude`), que só existem na versão hospedada no claude.ai.
No GitHub Pages o visual funciona, mas **não grava dados nem identifica usuários**.
Para rodar fora do Claude é preciso trocar essa camada por um backend (ex.: Supabase ou Firebase:
login por e-mail, banco de dados e storage). Os pontos a trocar estão na função `init()` e nas chamadas `db.collection(...)` e `assets.upload(...)` do `index.html`.
